// const studentNamename = document.querySelector("#studentName");
// console.log(studentName);
// const button = document.querySelector(".btn");

// button.addEventListener("click",addName);

// const tableName = document.querySelector("#tName");

// function addName(){
//     console.log("button clicked")
//     console.log(studentName.value);

//     const row = document.createElement("p");
//     row.innerHTML=studentName.value;
// }


// const form = document.querySelector('form');

// function addToTable(e){
//     e.preventDefault();
//     const studentName = document.getElementById('name').value;
//     const studentId = document.getElementById('studentId').value;
//     const emaliId = document.getElementById('emailId').value;
//     const contactNo = document.getElementById('contactNo.').value;
//     alert(studentName+studentId+emaliId+contactNo);

// }

document.getElementById('studentForm').addEventListener('submit', addName);

function addName(event) {
    event.preventDefault();

    
    const studentName = document.getElementById('studentName').value;
    const studentId = document.getElementById('studentId').value;
    const emailId = document.getElementById('emailId').value;
    const contactNo = document.getElementById('contactNo.').value;

    //----new row
    const tableBody = document.querySelector('#studentTable tbody');
    const newRow = document.createElement('tr');

    newRow.innerHTML = `
        <td>${studentName}</td>
        <td>${studentId}</td>
        <td>${emailId}</td>
        <td>${contactNo}</td>
        <td>
             <button onclick="editRow(this)" id="editBtn">Edit</button>
             <button onclick="deleteRow(this)" id="deletBtn">Delete</button>
        </td>
    `;

    // Appending newRow to the tablebody
    tableBody.appendChild(newRow);

    // Clear the input fields
    document.getElementById('studentForm').reset();
}

// Function to edit a row
function editRow(button) {
    const row = button.parentElement.parentElement;
    document.getElementById('studentName').value = row.cells[0].innerText;
    document.getElementById('studentId').value = row.cells[1].innerText;
    document.getElementById('emailId').value = row.cells[2].innerText;
    document.getElementById('contactNo.').value = row.cells[3].innerText;

    // Remove the row from the table
    row.remove();
}

// Function to delete a row
function deleteRow(button) {
    const row = button.parentElement.parentElement;
    row.remove();
}


















































// document.getElementById('studentForm').addEventListener('submit', function(event) {
//     event.preventDefault();

// const studentName = document.getElementById('name').value;
// const studentId = document.getElementById('studentId').value;
// const emaliId = document.getElementById('emailId').value;
// const contactNo = document.getElementById('contactNo.').value;


// if (id) {
//     // Editing existing student
//     const row = document.getElementById(id);
//     row.cells[0].innerText =studentName ;
//     row.cells[1].innerText = studentId;
//     row.cells[2].innerText = emaliId;
//     row.cells[3].innerText = contactNo;

//     document.getElementById('studentNmame').value = '';
// } else {
//     // Adding new student
//     const tableBody = document.querySelector('#studentTable tbody');
//     const newRow = tableBody.insertRow();
//     newRow.id = Date.now(); // Unique ID based on timestamp

//     newRow.insertCell(0).innerText = studentName;
//     newRow.insertCell(1).innerText = studentId;
//     newRow.insertCell(2).innerText = emaliId;
//     newRow.insertCell(3).innerText = contactNo;

//     const actionsCell = newRow.insertCell(4);
//     actionsCell.innerHTML = `<button onclick="editRecord('${newRow.id}')">Edit</button>
//                              <button onclick="deleteRecord('${newRow.id}')">Delete</button>`;
// }

// this.reset();
// });